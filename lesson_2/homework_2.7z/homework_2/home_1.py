my_list_1 = [5, 3.6, -4, "dog", None, False]
for el in my_list_1:
    print(type(el))